import javax.swing.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

/**
*   This class is responsible for creating, updating and maintaining 
*   the screen of the program for creating an account by communicating with 
*   model (user database) of the program. The screen is displayed in case 
*   the user has chosen an option of creating a new account on the log in screen.
*
*   @author Team 7 Restaurant Review Application
*   @version 1.0
* */
public class CreateAccountFrame extends JFrame   {
     
	private JFrame accountFrame;   // instance variable for the JFrame
	
	/********************************
	 *  This method is responsible for creating and organizing the layout of
	 *  the screen for creating user account.
	 *  
	 *  @version 1.0
	 */
	public void createFrame()
	{
		accountFrame = new JFrame("Create Account");
		
		// create labels and buttons, organize them in an appropriate layout
		JLabel label = new JLabel("Please enter information below:");
		label.setFont(new Font("Sarif", Font.PLAIN, 40));
		label.setForeground(Color.BLUE);
		JLabel username = new JLabel("Username:");
		username.setFont(new Font("Sarif", Font.PLAIN, 20));
		JLabel password = new JLabel("Password:");
		password.setFont(new Font("Sarif", Font.PLAIN, 20));
		JLabel confirmPassword = new JLabel("Confirm password:");
		confirmPassword.setFont(new Font("Sarif", Font.PLAIN, 20));
		JButton create = new JButton("Create");
		JButton back = new JButton("Back to log in");
		JTextField userField = new JTextField();
		userField.setPreferredSize(new Dimension(150,20));
		JPasswordField passwordField = new JPasswordField();
		passwordField.setPreferredSize(new Dimension(150,20));
		JPasswordField confirmField = new JPasswordField();
		confirmField.setPreferredSize(new Dimension(150,20));
		
		JPanel labelPanel = new JPanel();
		labelPanel.add(Box.createHorizontalStrut(20));
		labelPanel.add(label);
		labelPanel.setMaximumSize(new Dimension(1000,100));
		
		JPanel usernamePanel = new JPanel();
		usernamePanel.add(Box.createHorizontalStrut(73));
		usernamePanel.add(username);
		usernamePanel.add(userField);
		usernamePanel.setMaximumSize(new Dimension(350,50));
		usernamePanel.setBackground(Color.RED);
		
		JPanel passwordPanel = new JPanel();
		passwordPanel.add(Box.createHorizontalStrut(80));
		passwordPanel.add(password);
		passwordPanel.add(passwordField);
		passwordPanel.setMaximumSize(new Dimension(350,50));
		passwordPanel.setBackground(Color.YELLOW);
		
		JPanel confirmPanel = new JPanel();
		confirmPanel.add(confirmPassword);
		confirmPanel.add(confirmField);
		confirmPanel.setMaximumSize(new Dimension(350,50));
		confirmPanel.setBackground(Color.GREEN);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(back);
		buttonPanel.add(Box.createHorizontalStrut(115));
		buttonPanel.add(create);
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
		centerPanel.add(Box.createVerticalStrut(100));
		centerPanel.add(labelPanel);
		centerPanel.add(Box.createVerticalStrut(100));
		centerPanel.add(usernamePanel);
		centerPanel.add(passwordPanel);
		centerPanel.add(confirmPanel);
		centerPanel.add(buttonPanel);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BorderLayout());
		finalPanel.add(centerPanel, BorderLayout.CENTER);
		
		// action listener for create account JButton
		create.addActionListener(new ActionListener()    {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String userString = userField.getText();  // string entered in username field
				String userPassword = passwordField.getText();  // string entered in password field
				String userConfirm = confirmField.getText();  // string entered in confirm password field
				// check if user with given username is already in user database
				if(DatabaseManager.userInDatabase(userString))
				{
					// if user already in database prompt user for a different username
					JOptionPane.showMessageDialog(accountFrame, "The account with this username already exists." +
							"Please choose a different username");
					 // clear text from all fields
					 userField.setText(""); 
					 passwordField.setText("");
					 confirmField.setText("");
					 userField.requestFocusInWindow();
				}
				// passwords enterd in password and confirm password fields do not match
				else if(!userPassword.equals(userConfirm))
				 {
					// display error message
					 JOptionPane.showMessageDialog(accountFrame,  "Passwords entered must match");
					// clear text from fields
					 passwordField.setText("");
					 confirmField.setText("");
					 passwordField.requestFocusInWindow();
				 }
				// user did not enter any password
				 else if(userPassword.length() == 0 && userConfirm.length() == 0)
				 {
					 JOptionPane.showMessageDialog(accountFrame,  "Password must contain at least 1 character");
				 }
				// information successfully added to user database
				 else if(DatabaseManager.insertInUserDatabase(userString, userPassword))
				 {
					 hideScreen();  // hide current screen
					 // create and display account confirmation screen
					 AccountConfirmationScreen screen = new AccountConfirmationScreen();
					 screen.createConfirmationFrame();
				 }
			}			
		});
		
		// action listener for "back" button (takes user back to log in screen)
		back.addActionListener(new ActionListener()   {
			public void actionPerformed(ActionEvent e)
			{
				hideScreen();   // hide current screen
				// create and display log in screen
				LogInScreen screen = new LogInScreen();
				screen.createLogInPage();
			}
		});
		
		accountFrame.add(finalPanel);
		accountFrame.getContentPane().setBackground(Color.BLUE);
		accountFrame.setPreferredSize(new Dimension(2000,2000));
		accountFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		accountFrame.pack();
		accountFrame.setVisible(true);
	}
	
   /*************************
   * This method hides the current screen
   * 
   * @version 1.0
   */
	public void hideScreen()
	{
		accountFrame.setVisible(false);
	}
}

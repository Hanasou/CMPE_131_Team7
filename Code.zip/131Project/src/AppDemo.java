import java.util.ArrayList;

/**
 * This class was created for testing purposes only. Use it to test the 
 * log in requirement of the program
 *
 * Team 7 Restaurant Review Application
 * @version 1.0
 */
public class AppDemo
{
	
  public static void main(String[] args)
  {
        LogInScreen manager = new LogInScreen();
        manager.createLogInPage();
   }   
}

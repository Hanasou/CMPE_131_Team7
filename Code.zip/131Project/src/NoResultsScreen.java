import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Font;
/**
 * This class is responsible for creating organizing and maintaining the screen that is displayed
 * in case the search for a restaurant produced no results.
 *
 * @author Team 7 Restaurant Review Application
 * @version 1.0
 */
public class NoResultsScreen extends JFrame
{
      private JFrame searchResultFrame;   // instance variable for JFrame
      
    /************************
     * This method creates and organizes the screen displayed if restaurant search
     * produced no results
     * 
     * @param restaurant entered by a user
     * @version 1.0
     */
    public void createNoFoundRestaurantScreen(String restaurant)
    {
        searchResultFrame = new JFrame("Search Results");
        
        // create labels and buttons, organize them in a preferred layout
        JLabel result = new JLabel("Hmmm... We did not find any matches in our database. Please choose from the following options:");
        result.setForeground(Color.RED);
        result.setFont(new Font("Serif", Font.PLAIN, 30));
        JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JButton logOutButton = new JButton("Log out");
        JButton newSearch = new JButton("New Search");
        JButton addRestaurant = new JButton("Add restaurant and review");
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(10));
        welcomePanel.setMaximumSize(new Dimension(300,200));
        welcomePanel.setBackground(Color.GREEN);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(20));
        logOutPanel.add(logOutButton);
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel topLeftPanel = new JPanel();
        topLeftPanel.setLayout(new BoxLayout(topLeftPanel, BoxLayout.PAGE_AXIS));
        topLeftPanel.setBackground(Color.GREEN);
        topLeftPanel.add(Box.createVerticalStrut(10));
        topLeftPanel.add(welcomePanel);
        topLeftPanel.add(logOutPanel);
        
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/SadFace.jpeg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(500,300,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(image);
        
        JPanel resultPanel = new JPanel();
        resultPanel.add(Box.createHorizontalStrut(100));
        resultPanel.add(result);
        resultPanel.setMaximumSize(new Dimension(1500,500));
        
        JPanel restaurantPanel = new JPanel();
        restaurantPanel.setBackground(Color.CYAN);
        restaurantPanel.add(addRestaurant);
        restaurantPanel.add(newSearch);
        
        JPanel combinedPanel = new JPanel();
        combinedPanel.setLayout(new BoxLayout(combinedPanel, BoxLayout.PAGE_AXIS));
        combinedPanel.add(imageLabel);
        combinedPanel.add(Box.createVerticalStrut(50));
        combinedPanel.add(resultPanel);
        combinedPanel.add(restaurantPanel);
        combinedPanel.setBackground(Color.BLUE);
        
        JPanel finalPanel = new JPanel(new BorderLayout());
        finalPanel.add(combinedPanel, BorderLayout.CENTER);
        finalPanel.add(topLeftPanel, BorderLayout.EAST);
        
        // action listener for the button that allows user to execute new search
        newSearch.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();   // hide current screen
                // create and display the screen that lets user execute new restaurant search
                SearchScreen search = new SearchScreen();
                search.createPage();
            }
        });
        
        // action listener for the button that allows user to add new restaurant to database
        addRestaurant.addActionListener(new ActionListener() {
        	      public void actionPerformed(ActionEvent e)
        	      {
        	    	      ReviewScreen.newRestaurant = true;   // lets database manager know that new restaurant needs to be added
        	    	      hideScreen();   // hide current screen
        	    	      // creates and displays the screen where user is able to write and post a new review for a restaurant
        	    	      ReviewScreen screen = new ReviewScreen();
        	    	      screen.createReviewScreen(restaurant);
        	      }
        });
        
        // action listener for log out button
        logOutButton.addActionListener(new ActionListener()     {
               public void actionPerformed(ActionEvent e)
               {
                  hideScreen();   // hide current screen
                  // create and display screen confirming the log out
                  LogOutScreen screen = new LogOutScreen();
                  screen.createLogOutFrame();
                }
        });
        searchResultFrame.setPreferredSize(new Dimension(2000,2000));
        searchResultFrame.add(finalPanel);
        searchResultFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        searchResultFrame.pack();
        searchResultFrame.setVisible(true);
    }
    
    /*************************
     * This method hides the current screen screen
	 * 
	 * @version 1.0
	 */
    public void hideScreen()
    {
       searchResultFrame.setVisible(false);   
    }
}
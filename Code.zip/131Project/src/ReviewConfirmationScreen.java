import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
/**
 *  This class is responsible for creating, organizing and maintaining the screen that is displayed
 *  after a user successfully added a review into the database
 *  
 *  @author Team 7 Restaurant Review Application
*   @version 1.0
 */
public class ReviewConfirmationScreen extends JFrame     {

	private JFrame confirmScreen;    // instance variable for JFrame
	
	/********************************
	   *  This method is responsible for creating and organizing the layout of
	   *  the review confirmation screen.
	   *  
	   *  @param restaurant for which a new review has been posted
	   *  @version 1.0
	   */
	public void createScreen(String restaurant)
	{
		confirmScreen = new JFrame("Confirm Review Submission");
		
		// create labels and buttons, organize them in a preferred layout
		JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
	    welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
	    JButton logOutButton = new JButton("Log out");
		JLabel confirmLabel = new JLabel("Thank you for submitting your review! We'll take it from here!");
		confirmLabel.setFont(new Font("Serif", Font.PLAIN, 30));
		JButton backToSearch = new JButton("New search");
		JButton seeReviews = new JButton("See reviews");
	    
	    ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/ReviewConfirm.jpg");
	    Image picture = image.getImage();
	    Image newImage = picture.getScaledInstance(1000,500,Image.SCALE_SMOOTH);
	    image = new ImageIcon(newImage);
	    JLabel restaurantLabel = new JLabel(image);    
	     
	    JPanel imagePanel = new JPanel(); 
	    imagePanel.add(restaurantLabel);
	    imagePanel.setMaximumSize(new Dimension(1000,500));
		
		JPanel labelPanel = new JPanel();
		labelPanel.add(Box.createHorizontalStrut(100));
		labelPanel.add(confirmLabel);
		labelPanel.setMaximumSize(new Dimension(2000,150));
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(Box.createHorizontalStrut(200));
		buttonPanel.add(seeReviews);
		buttonPanel.add(Box.createHorizontalStrut(100));
		buttonPanel.add(backToSearch);
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
		centerPanel.add(imagePanel);
		centerPanel.add(labelPanel);
		centerPanel.add(buttonPanel);
		
	    JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(20));
        welcomePanel.setMaximumSize(new Dimension(300,50));
        welcomePanel.setBackground(Color.RED);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(150));
        logOutPanel.add(logOutButton);
        logOutPanel.setMaximumSize(new Dimension(300,50));
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS));
        eastPanel.add(welcomePanel);
        eastPanel.add(logOutPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(centerPanel, BorderLayout.CENTER);
        finalPanel.add(eastPanel, BorderLayout.EAST);
        
        // action listener for the button that allows user to execute a new search
        backToSearch.addActionListener(new ActionListener()   {
        	         public void actionPerformed(ActionEvent e)
        	         {
        	        	    hideScreen();   // hide current screen
        	        	    // create and display the screen where a use can execute new search
        	        	    SearchScreen screen = new SearchScreen();
        	        	    screen.createPage();
        	         }
        });
        
        // action listener for the button that allows user to see reviews for a given restaurant
        seeReviews.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	     {
        	    	    hideScreen();   // hide current screen
        	    	    // get reviews available for a given restaurant
        	    	    ArrayList<String> reviews = DatabaseManager.getReviews(restaurant);
        	    	    // create and display the screen where a user can see all available reviews for a given restaurant
        	    	    DisplayReviewsScreen screen = new DisplayReviewsScreen();
        	    	    screen.createScreen(restaurant, reviews);
        	     }
        });
        
        // action listener for the button that allows user to log out
        logOutButton.addActionListener(new ActionListener()   {
        	        public void actionPerformed(ActionEvent e)
        	        {
        	        	  hideScreen();   // hide current screen
        	        	  // create and display the screen confirming user log out
        	        	  LogOutScreen screen = new LogOutScreen();
        	        	  screen.createLogOutFrame();
        	        }
        });
        
	    confirmScreen.add(finalPanel);
	    confirmScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);
		confirmScreen.setPreferredSize(new Dimension(2000,2000));
		confirmScreen.pack();
		confirmScreen.setVisible(true);
	}
	
	/*************************
     * This method hides the current screen
	 * 
	 * @version 1.0
	 */
	public void hideScreen()
	{
		confirmScreen.setVisible(false);
	}
}

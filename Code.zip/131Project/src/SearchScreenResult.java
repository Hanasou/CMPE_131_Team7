
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Font;
/**
 * This class is responsible for creating, organizing and maintaining the screen that
 * displays the search results for a particular restaurant.
 *
 * @author Team 7 Restaurant Review Application
 * @version 1.0
 */
public class SearchScreenResult extends JFrame
{
    private JFrame searchResultFrame;  // instance variable for JFrame
    
    /********************************
     *  This method is responsible for creating and organizing the layout of
     *  the search result screen.
     *  
     *  @param restaurantName - name of a restaurant entered by user
     *  @version 1.0
     */
    public void createFoundRestaurantScreen(String restaurantName)
    {
        searchResultFrame = new JFrame("Search Results");
        
        // create labels and buttons, organize them in a desired layout
        JLabel name = new JLabel(restaurantName);
        name.setFont(new Font("Serif", Font.PLAIN, 25));
        JLabel result = new JLabel("Your search produced the following result:");
        result.setForeground(Color.RED);
        result.setFont(new Font("Serif", Font.PLAIN, 30));
        JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JButton logOutButton = new JButton("Log out");
        JButton displayReview = new JButton("See reviews");
        JButton writeReview = new JButton("Write Review");
        JButton newSearch = new JButton("New Search");
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(10));
        welcomePanel.setMaximumSize(new Dimension(400,200));
        welcomePanel.setBackground(Color.GREEN);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(20));
        logOutPanel.add(logOutButton);
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel topLeftPanel = new JPanel();
        topLeftPanel.setLayout(new BoxLayout(topLeftPanel, BoxLayout.PAGE_AXIS));
        topLeftPanel.setBackground(Color.GREEN);
        topLeftPanel.add(Box.createVerticalStrut(10));
        topLeftPanel.add(welcomePanel);
        topLeftPanel.add(logOutPanel);
        
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/Restaurant3.jpeg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(1000,300,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(image);
        
        JPanel resultPanel = new JPanel();
        resultPanel.add(Box.createHorizontalStrut(100));
        resultPanel.add(result);
        resultPanel.setMaximumSize(new Dimension(600,500));
        
        JPanel restaurantPanel = new JPanel();
        restaurantPanel.setBackground(Color.BLUE);
        restaurantPanel.add(name);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(displayReview);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(writeReview);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(newSearch);
        
        JPanel combinedPanel = new JPanel();
        combinedPanel.setLayout(new BoxLayout(combinedPanel, BoxLayout.PAGE_AXIS));
        combinedPanel.add(imageLabel);
        combinedPanel.add(Box.createVerticalStrut(50));
        combinedPanel.add(resultPanel);
        combinedPanel.add(restaurantPanel);
        
        JPanel finalPanel = new JPanel(new BorderLayout());
        finalPanel.add(combinedPanel, BorderLayout.CENTER);
        finalPanel.add(topLeftPanel, BorderLayout.EAST);
        
        // action listener for a new search button which allows user to execute new restaurant search
        newSearch.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();      // hide current screen
                // create and display search screen where user can execute new search
                SearchScreen search = new SearchScreen();
                search.createPage();
            }
        });
        
        // action listener for the screen that displays available reviews for a particular restaurant
        displayReview.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	     {
        	    	    hideScreen();   // hide current screen
        	    	    // retrieve available reviews for a restaurant from restaurant database
        	    	    ArrayList<String> reviews = DatabaseManager.getReviews(restaurantName);
        	    	    // create and display the screen that shows restaurant reviews
        	    	    DisplayReviewsScreen screen = new DisplayReviewsScreen();
        	    	    screen.createScreen(restaurantName, reviews);
        	     }
        });
        
        // action listener for the button that allows user to log out
        logOutButton.addActionListener(new ActionListener()   {
               public void actionPerformed(ActionEvent e)
               {
            	       hideScreen();   // hide current screen
            	       // create and display log out confirmation screen
                   LogOutScreen screen = new LogOutScreen();
                   screen.createLogOutFrame();
                }
        });
        
        // action listener for the button that takes user to the screen where they can write a restaurant review
        writeReview.addActionListener(new ActionListener()   {
               public void actionPerformed(ActionEvent e)
               {
                   hideScreen();   // hide current screen
                   // create and display the screen where user can write a review for a restaurant
                   ReviewScreen screen = new ReviewScreen();
                   screen.createReviewScreen(restaurantName);
                }
        });
        searchResultFrame.setPreferredSize(new Dimension(2000,2000));
        searchResultFrame.add(finalPanel);
        searchResultFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        searchResultFrame.pack();
        searchResultFrame.setVisible(true);
    }
    
	/*************************
  * This method hides the current screen
	 * 
	 * @version 1.0
	 */
    public void hideScreen()
    {
       searchResultFrame.setVisible(false);   
    }
}


import javax.swing.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
/**
 * This class is responsible for creating, organizing and maintaining the review screen
 * which is displayed when a user chooses an option of writing a review of a restaurant.
 *
 * @author Team 7 Restaurant Review Application
 * @version 1.0
 */
public class ReviewScreen extends JFrame
{
    private JFrame reviewScreen;   // instance variable for JFrame
    public static boolean newRestaurant = false;  // static variable which indicates whether a new restaurant
                                                  // is being added to restaurant database
    /********************************
     *  This method is responsible for creating and organizing the layout of
     *  the review screen.
     *  
     *  @param restaurantName - the name of the restaurant entered by a user
     *  @version 1.0
     */
    public void createReviewScreen(String restaurantName)
    {
        reviewScreen = new JFrame("Write Review");
        
        // create labels and buttons, organize them in a desired layout
        JLabel label = new JLabel("Please submit your review below:");
        label.setFont(new Font("Serif", Font.PLAIN, 30));
        label.setForeground(Color.RED);
        JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JButton logOutButton = new JButton("Log out");
        JButton backToSearchResults = new JButton("Back to search results");
        
        JTextArea reviewField = new JTextArea();
        reviewField.setPreferredSize(new Dimension(400,500));
        reviewField.setLineWrap(true);
        reviewField.setWrapStyleWord(true);
        JButton submit = new JButton("Submit");
        
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/Review.jpg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(1000,800,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(image);
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.setMaximumSize(new Dimension(400,50));
        welcomePanel.setBackground(Color.GREEN);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(30));
        logOutPanel.add(logOutButton);
        logOutPanel.setBackground(Color.YELLOW);
        
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(welcomePanel);
        rightPanel.add(logOutPanel);
        rightPanel.setBackground(Color.YELLOW);
        
        JPanel labelPanel = new JPanel();
        labelPanel.add(Box.createHorizontalStrut(100));
        labelPanel.add(label);
        labelPanel.setBackground(Color.GREEN);
        labelPanel.setMaximumSize(new Dimension(2000,50));
        
        JPanel reviewPanel = new JPanel();
        reviewPanel.add(Box.createHorizontalStrut(100));
        reviewPanel.add(reviewField);
        reviewPanel.setMaximumSize(new Dimension(2000, 500));
        
        JPanel submitPanel = new JPanel();
        submitPanel.add(Box.createHorizontalStrut(120));
        submitPanel.add(backToSearchResults);
        submitPanel.add(Box.createHorizontalStrut(120));
        submitPanel.add(submit);
        submitPanel.setMaximumSize(new Dimension(2000,50));
        submitPanel.setBackground(Color.BLUE);
        
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(labelPanel);
        centerPanel.add(reviewPanel);
        centerPanel.add(submitPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(centerPanel, BorderLayout.WEST);
        finalPanel.add(imageLabel, BorderLayout.CENTER);
        finalPanel.add(rightPanel, BorderLayout.EAST);
        
        // action listener for log out button
        logOutButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();   // hide current screen
                // create and display log out confirmation screen
                LogOutScreen screen = new LogOutScreen();
                screen.createLogOutFrame();
            }
        });
        
        // action listener for the button that takes user back to search results
        backToSearchResults.addActionListener(new ActionListener() {
        	      public void actionPerformed(ActionEvent e)
        	      {
        	    	     hideScreen();   // hide current screen
        	    	     // create and display the screen with search results for a particular restaurant
        	    	     SearchScreenResult screen = new SearchScreenResult();
        	    	     screen.createFoundRestaurantScreen(restaurantName);
        	      }
        });
        
        // action listener for the submit review button
        submit.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	    {
        	    	   String review = reviewField.getText();  // get review text
        	    	   // if user did not enter any text display error message
        	    	   if(review.length() == 0)
        	    	   {
        	    		   JOptionPane.showMessageDialog(reviewScreen, "Please enter the text of your review.");
        	    	   }
        	    	   else  // user entered review
        	    	   {
        	    	      hideScreen();  // hide current screen
        	    	          
        	    	          // add review to restaurant database
        	      	      if(DatabaseManager.insertInRestaurantDatabase(restaurantName, review))
        	    	            {
        	      	    	     // create and display review confirmation screen
        	                  ReviewConfirmationScreen screen = new ReviewConfirmationScreen();
        	                  screen.createScreen(restaurantName);
        	         	    }
        	    	   }
        	    }
        });
        reviewScreen.add(finalPanel);
        reviewScreen.setPreferredSize(new Dimension(2000,2000));
        reviewScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);
        reviewScreen.pack();
        reviewScreen.setVisible(true);
    }
    
	/*************************
     * This method hides the account confirmation screen
	 * 
	 * @version 1.0
	 */
    public void hideScreen()
    {
        reviewScreen.setVisible(false);   
    }
}

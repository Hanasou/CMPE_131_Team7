
import javax.swing.*;
import java.awt.event.*;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Color;
/**
 * This class is responsible for creating a log out screen (the screen that
 * a user sees after pressing the "Log Out" button).
 *
 * @author Team 7 Restaurant Review Application
 * @version 1.0
 */
public class LogOutScreen extends JFrame
{
   private JFrame logOutFrame;   // instance variable for the log out frame
   
   /*********************************
    *  This method is responsible for creating and organizing the layout 
    *  of the log out page.
    *  
    *  @version 1.0
    */
   public void createLogOutFrame()
   {
      // create necessary JComponents used in the screen
      logOutFrame = new JFrame("Log out screen");
      JLabel logOut = new JLabel("You are logged out.");
      logOut.setFont(new Font("Sarif", Font.PLAIN, 40));
      JLabel nextLabel = new JLabel("Thanks for visiting! Hope to see you back soon!");
      nextLabel.setFont(new Font("Sarif", Font.PLAIN, 40));
      JButton startOver = new JButton("Start over");
      
      // put the image on the screen in to a JLabel
      ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/ThumbsUp.png");
      Image picture = image.getImage();
      Image newImage = picture.getScaledInstance(800,400,Image.SCALE_SMOOTH);
      image = new ImageIcon(newImage);
      JLabel imageLabel = new JLabel(image);
      
      // add label with image into JPanel
      JPanel imagePanel = new JPanel();
      imagePanel.add(imageLabel);
      imagePanel.setBackground(Color.RED);
      imagePanel.setMaximumSize(new Dimension(2000,410));
      
      // create a JPanel for the logged out label and add the label to this panel
      JPanel logOutPanel = new JPanel();
      logOutPanel.add(Box.createHorizontalStrut(150));
      logOutPanel.add(logOut);
      logOutPanel.setBackground(Color.GREEN);
      logOutPanel.setMaximumSize(new Dimension(2000,100));
      
      // create a JPanel for the Good Bye label and add the label to this panel
      JPanel lowerPanel = new JPanel();
      lowerPanel.add(nextLabel);
      lowerPanel.setMaximumSize(new Dimension(2000,100));
      lowerPanel.setBackground(Color.BLUE);
      
      // create the center panel with BoxLayout and add all above panels to it
      JPanel centerPanel = new JPanel();
      centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
      centerPanel.add(imagePanel);
      centerPanel.add(logOutPanel);
      centerPanel.add(lowerPanel);
      centerPanel.add(startOver);
      
      // create the final big panel and put the above panel at its center
      JPanel finalPanel = new JPanel(new BorderLayout());
      finalPanel.add(centerPanel, BorderLayout.CENTER);
      
      // action listener for the "Start Over" button
      startOver.addActionListener(new ActionListener()   {
              public void actionPerformed(ActionEvent e)
              {
                  hideScreen();  // hide current screen
                  LogInScreen screen = new LogInScreen(); // create log in screen
                  screen.createLogInPage();
                }
        });
      
      // add final panel to JFrame, set dimensions and set JFrame visible
      logOutFrame.add(finalPanel);
      logOutFrame.setPreferredSize(new Dimension(2000,2000));
      logOutFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
      logOutFrame.pack();
      logOutFrame.setVisible(true);
    }
    
   /************************************
    *  This method hides the log out screen once the "Start Over" button
    *  is pressed.
    *  
    *  @version 1.0
    */
   public void hideScreen()
   {
      logOutFrame.setVisible(false);  
    }
}
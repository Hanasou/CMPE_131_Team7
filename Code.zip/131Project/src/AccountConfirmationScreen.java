import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import javax.swing.*;
/**
*   This class is responsible for creating, updating and maintaining 
*   the account confirmation screen of the program by communicating with 
*   model (user database) of the program. The screen is displayed in case 
*   the user has successfully completed the process of creating an account
*   and all information has been added to the user database.
*
*   @author Team 7 Restaurant Review Application
*   @version 1.0
* */
public class AccountConfirmationScreen extends JFrame {

	private JFrame confirmationFrame;  // instance variable for the JFrame of the screen
	
/********************************
   *  This method is responsible for creating and organizing the layout of
   *  the account confirmation screen.
   *  
   *  @version 1.0
   */
	public void createConfirmationFrame()
	{
		confirmationFrame = new JFrame("Confirm Account Creation");
		
		// create labels and buttons of the page and choose layout
		JLabel thankYou = new JLabel("Thank you for creating an account with us!");
		thankYou.setFont(new Font("Sarif", Font.PLAIN, 40));
		thankYou.setForeground(Color.GREEN);
		JLabel set = new JLabel("You are all set!");
		set.setFont(new Font("Sarif", Font.PLAIN, 40));
		set.setForeground(Color.BLUE);
		JButton start = new JButton("Get started");
		
		ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/ConfirmAccount.jpg");
		Image temp = image.getImage();
	    Image newImage = temp.getScaledInstance(500,400,Image.SCALE_SMOOTH);
	    image = new ImageIcon(newImage);
		JLabel label = new JLabel(image);
		
		JPanel imagePanel = new JPanel();
		imagePanel.add(label);
		imagePanel.setMaximumSize(new Dimension(1000,100));
		
		JPanel thankyouPanel = new JPanel();
		thankyouPanel.add(thankYou);
		thankyouPanel.setMaximumSize(new Dimension(1000,200));
		
		JPanel setPanel = new JPanel();
		setPanel.add(set);
		setPanel.setMaximumSize(new Dimension(1000,200));
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(Box.createHorizontalStrut(20));
		buttonPanel.add(start);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BoxLayout(finalPanel, BoxLayout.PAGE_AXIS));
		finalPanel.add(Box.createVerticalStrut(50));
		finalPanel.add(thankyouPanel);
		finalPanel.add(imagePanel);
		finalPanel.add(setPanel);
		finalPanel.add(buttonPanel);
		
		// action listener for the start button (start over the application)
		start.addActionListener(new ActionListener()     {
			 public void actionPerformed(ActionEvent e)
			 {
				 hideScreen();  // hide current screen
				 LogInScreen screen = new LogInScreen();  // create and display log in screen
				 screen.createLogInPage();
			 }
		});
		
		confirmationFrame.setPreferredSize(new Dimension(2000,2000));
		confirmationFrame.add(finalPanel);
		confirmationFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		confirmationFrame.pack();
		confirmationFrame.setVisible(true);
	}
	
	/*************************
     * This method hides the account confirmation screen
	 * 
	 * @version 1.0
	 */
	public void hideScreen()
	{
		confirmationFrame.setVisible(false);
	}
}

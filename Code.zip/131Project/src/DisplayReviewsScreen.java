import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import javax.swing.*;
/**
 *  This class is responsible for creating organizing and maintaining the screen that displays
 *  the reviews of a given restaurant available in restaurant database.
 *  
 *  @author Team 7 Restaurant Review Application
 *  @version 1.0
 */
public class DisplayReviewsScreen extends JFrame {

	private JFrame displayScreen;  // instance variable of JFrame
	
	/********************************
	   *  This method is responsible for creating and organizing the layout of
	   *  the screen that displays reviews of a restaurant.
	   *  
	   *  @param restaurant - restaurant name entered by user
	   *  @param reviews - ArrayList of available reviews for a restaurant
	   *  @version 1.0
	   */
	public void createScreen(String restaurant, ArrayList<String> reviews)
	{
		displayScreen = new JFrame("Display Available Reviews");
		
		// create labels and buttons, organize them in a preferred layout
		JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
	    welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
	    JButton logOutButton = new JButton("Log out");
	    JLabel topLabel = new JLabel("Displaying available reviews for " + restaurant + ":");
	    topLabel.setFont(new Font("Serif", Font.PLAIN, 30));
	    JButton backToResults = new JButton("Back to search results");
	    JButton newSearch = new JButton("New search");
	    JButton review = new JButton("Review this restaurant");
	    
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(backToResults);
	    buttonPanel.add(Box.createHorizontalStrut(50));
	    buttonPanel.add(review);
	    buttonPanel.add(Box.createHorizontalStrut(50));
	    buttonPanel.add(newSearch);
	    buttonPanel.setMaximumSize(new Dimension(1000,100));
	    
	    JPanel labelPanel = new JPanel();
	    labelPanel.add(topLabel);
	    labelPanel.setMaximumSize(new Dimension(1000,100));
	    labelPanel.setBackground(Color.BLUE);
	    
	    JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(20));
        welcomePanel.setMaximumSize(new Dimension(300,50));
        welcomePanel.setBackground(Color.RED);
	    
	    JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(150));
        logOutPanel.add(logOutButton);
        logOutPanel.setMaximumSize(new Dimension(300,50));
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS));
        eastPanel.add(welcomePanel);
        eastPanel.add(logOutPanel);
		
        
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
        centerPanel.add(labelPanel);
        
        // add all reviews in ArrayList to the screen
        for(int i = 0; i < reviews.size(); i ++)
        {
        	   JTextArea field = new JTextArea();
        	   field.setMaximumSize(new Dimension(1000,50));
        	   field.setText(reviews.get(i));
        	   field.setLineWrap(true);
        	   field.setWrapStyleWord(true);
        	   field.setEnabled(false);
        	   centerPanel.add(field);
        	   centerPanel.add(Box.createVerticalStrut(20));
        }
        centerPanel.add(buttonPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(centerPanel, BorderLayout.CENTER);
        finalPanel.add(eastPanel, BorderLayout.EAST);
        
        // this action listener button takes user back to the search results
        backToResults.addActionListener(new ActionListener() {
        	       public void actionPerformed(ActionEvent e)
        	       {
        	    	      hideScreen(); // hide current screen
        	    	      // create and display the screen with search results
        	    	      SearchScreenResult screen = new SearchScreenResult();
        	    	      screen.createFoundRestaurantScreen(restaurant);
        	       }
        });
        
        // action Listener for the button that allows user to execute new search
        newSearch.addActionListener(new ActionListener()   {
        	      public void actionPerformed(ActionEvent e)
        	      {
        	    	     hideScreen();   // hide current screen
        	    	     // create and display the screen that allows user to execute new search
        	    	     SearchScreen screen = new SearchScreen();
        	    	     screen.createPage();
        	      }
        });
        
        // action listener for the button that takes a user to the page where they can post a review for a restaurant
        review.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	     {
        	    	    hideScreen();  // hide current screen
        	    	    // create and display screen where users can add a new review for a restaurant
        	    	    ReviewScreen screen = new ReviewScreen();
        	    	    screen.createReviewScreen(restaurant);
        	     }
        });
        
        // action listener for the button that allows a user to log out
        logOutButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();   // hide current screen
                // create and display the log out confirmation screen
                LogOutScreen manager = new LogOutScreen();
                manager.createLogOutFrame();
            }    
        });
        
        displayScreen.add(finalPanel);
		displayScreen.setPreferredSize(new Dimension(2000,2000));
		displayScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);
		displayScreen.pack();
		displayScreen.setVisible(true);
	}
	
	/*************************
     * This method hides the current screen
	 * 
	 * @version 1.0
	 */
	public void hideScreen()
	{
		displayScreen.setVisible(false);
	}
}
